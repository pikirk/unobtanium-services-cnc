import { Engraver, HandlerResult } from './types';
export declare const getEngraverById: (id: string) => Promise<HandlerResult<Engraver | {
    error: string;
}>>;
//# sourceMappingURL=get-engraver-by-id.d.ts.map