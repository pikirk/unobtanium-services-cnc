"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const get_engraver_1 = require("./get-engraver");
const get_engraver_by_id_1 = require("./get-engraver-by-id");
const utils_1 = require("./utils");
const handler = async (event) => {
    try {
        const method = event.httpMethod;
        const pathParameters = event.pathParameters;
        // Only handle GET requests
        if (method !== 'GET') {
            return (0, utils_1.formatResponse)({ error: 'Method not allowed' }, 405);
        }
        // GET /engraver/{id}
        if (pathParameters?.id) {
            const result = await (0, get_engraver_by_id_1.getEngraverById)(pathParameters.id);
            return (0, utils_1.formatResponse)(result.data, result.statusCode);
        }
        // GET /engraver (with optional pagination)
        const queryParams = event.queryStringParameters || {};
        const result = await (0, get_engraver_1.getEngravers)(queryParams);
        return (0, utils_1.formatResponse)(result.data, result.statusCode);
    }
    catch (error) {
        console.error('Handler error:', error);
        return (0, utils_1.formatResponse)({ error: 'Internal server error' }, 500);
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map