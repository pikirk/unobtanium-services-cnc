"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatResponse = void 0;
const formatResponse = (data, statusCode = 200) => {
    const response = {
        result: data,
        resultCode: statusCode
    };
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*', // Configure as needed
        },
        body: JSON.stringify(response, null, 2) // Pretty formatting
    };
};
exports.formatResponse = formatResponse;
//# sourceMappingURL=utils.js.map