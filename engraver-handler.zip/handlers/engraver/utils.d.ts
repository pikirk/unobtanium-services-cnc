import { APIGatewayProxyResult } from 'aws-lambda';
export declare const formatResponse: (data: any, statusCode?: number) => APIGatewayProxyResult;
//# sourceMappingURL=utils.d.ts.map