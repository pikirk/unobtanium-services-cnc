import { PaginationParams, PaginatedEngravers, HandlerResult } from './types';
export declare const getEngravers: (queryParams: PaginationParams) => Promise<HandlerResult<PaginatedEngravers>>;
//# sourceMappingURL=get-engraver.d.ts.map